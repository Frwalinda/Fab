<?php

namespace App\Filament\Resources\FAQsResource\Pages;

use App\Filament\Resources\FAQsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFAQs extends CreateRecord
{
    protected static string $resource = FAQsResource::class;
}
