<?php

namespace App\Filament\Resources\DownloadsResource\Pages;

use App\Filament\Resources\DownloadsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDownloads extends CreateRecord
{
    protected static string $resource = DownloadsResource::class;
}
