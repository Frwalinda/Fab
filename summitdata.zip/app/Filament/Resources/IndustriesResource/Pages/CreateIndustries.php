<?php

namespace App\Filament\Resources\IndustriesResource\Pages;

use App\Filament\Resources\IndustriesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateIndustries extends CreateRecord
{
    protected static string $resource = IndustriesResource::class;
}
